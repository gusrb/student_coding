package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    // Access a Cloud Firestore instance from your Activity
    val db = FirebaseFirestore.getInstance()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()
        var btl=BTL()
        button.setOnClickListener(btl)
    }
    public override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        val currentUser = auth.currentUser
    }
    inner class BTL : View.OnClickListener{
        override fun onClick(v: View?) {
            var email = editText.text.toString()
            var password = editText2.text.toString()

            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener() { task ->
                    if (task.isSuccessful) {
                        // Sign in success, update UI with the signed-in user's information
                        var t1 = Toast.makeText(baseContext,"회원가입 성공",Toast.LENGTH_SHORT).show()
                        val user = auth.currentUser
                    } else {

                        Toast.makeText(baseContext, "회원가입 실패",
                            Toast.LENGTH_SHORT).show()

                    }

                    // ...
                }

            val user = hashMapOf(
                "e-mail" to email,
                "password" to password
            )

            db.collection("users").document(email).set(user)
                .addOnSuccessListener { documentReference ->
                    Toast.makeText(baseContext, "저장 성공",
                        Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(baseContext, "저장 실패", Toast.LENGTH_SHORT).show()
                }
        }
    }
}
