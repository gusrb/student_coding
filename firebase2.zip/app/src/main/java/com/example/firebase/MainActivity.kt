package com.example.firebase

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import androidx.core.app.ComponentActivity
import androidx.core.app.ComponentActivity.ExtraData
import androidx.core.content.ContextCompat.getSystemService
import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import android.widget.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val id = findViewById<EditText>(R.id.editText)
        val pw = findViewById<EditText>(R.id.editText2)
        val showButton = findViewById<Button>(R.id.button)



        if(id!=null)
            progressBar.incrementProgressBy(20)
        if(pw!=null)
            progressBar.incrementProgressBy(20)

        if(checkBox.isChecked ==true)
            progressBar.incrementProgressBy(20)
        if(checkBox2.isChecked ==true)
            progressBar.incrementProgressBy(20)
        if(checkBox3.isChecked ==true)
            progressBar.incrementProgressBy(20)
        if(radioButton.isChecked==true)
            progressBar.incrementProgressBy(20)
        if(radioButton2.isChecked==true)
            progressBar.incrementProgressBy(20)

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {

            override fun onProgressChanged(seekBar: SeekBar, i: Int, b: Boolean) {
                // Display the current progress of SeekBar
                textView3.text = " $i"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {

            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                progressBar.incrementProgressBy(20)

            }
        })



        showButton.setOnClickListener {
            val text1 = editText.text
            val text2 = editText2.text
            val gender : String="없음"
            var height = textView3.text
            val radio : RadioButton = findViewById(radiogroup.checkedRadioButtonId)

            when (radiogroup.checkedRadioButtonId) {
                R.id.radioButton -> {Toast.makeText(this, "Man", Toast.LENGTH_SHORT).show()
                    progressBar.incrementProgressBy(20)}
                R.id.radioButton2 -> {Toast.makeText(this, "Woman", Toast.LENGTH_SHORT).show()
                    progressBar.incrementProgressBy(20)}
            }
            if (checkBox.isChecked == true) {
                Toast.makeText(this, "id: "+text1+" pw: "+text2+" gender: "+"${radio.text}"+" Height :"+height+" Hobby: Soccer", Toast.LENGTH_SHORT).show()


            }
            if (checkBox2.isChecked == true) {
                Toast.makeText(this, "id: "+text1+" pw: "+text2+" gender: "+"${radio.text}"+" Height :"+height+" Hobby: Basketball", Toast.LENGTH_SHORT).show()

            }
            if (checkBox3.isChecked == true) {
                Toast.makeText(this, "id: "+text1+" pw: "+text2+" gender: "+"${radio.text}"+" Height :"+height+" Hobby: baseball", Toast.LENGTH_SHORT).show()

            }
        }
    }
}

